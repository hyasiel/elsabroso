const express = require("express");
const router = express.Router();
const { UploadProducts } = require("../controllers/ProductController");

const { upload } = require("../middlewares/UploadMiddleware");

//el admin envia los datos a estas ruta

//router.get("/getProducts");
router.post("/updateproducts", upload.single("image"), async (req, res) => {
  try {
    //llamamos a controller product y pasamos parametros

    const response = await UploadProducts(req);
    res.
  } catch (e) {
    console.log("error de ruter update product: ", e);
  }
});
//router.delete("/deleteProduct");

module.exports = router;
