const bcrypt = require("bcrypt");
const repositories = require("../repositories/UserRepositories");

require("dotenv").config();
const jwt = require("jsonwebtoken");

//clase para manejar la logica de actualizacion de productos, se encarga de enviar datos al user repository
class ProductService {
  constructor() {
    this.userRepository = new repositories.UserRepository();
    this.AdminRepository = new repositories.AdminRepository();
  }

  //admin functions
  async uploadProducts(user, product) {
    try {
      //verificamos si el usuario es admin
      const userRole = await this.UserRepository.findById(user);
      if (!userRole === "admin") return "Unauthorized";

      const { title, description, imageUrl, category } = product;

      //si es admin publicamos producto en db
      const responsedPoduct = await this.AdminRepository.createNewPost(
        title,
        description,
        imageUrl,
        category,
      );

      console.log(
        "responseProducts de product service dice: ",
        responsedPoduct,
      );
      return responsedPoduct;
    } catch (err) {
      console.log("error de product sercice: ", err);
    }
  }
}

module.exports = ProductService;
