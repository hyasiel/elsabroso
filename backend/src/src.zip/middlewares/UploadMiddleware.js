const multer = require("multer");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const path = require("path");

const storage = multer.diskStorage({
  destination: "../uploads/products",
  filename: (req, file, cb) => {
    cb(null.Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

//upload middleware

const UploadMiddleware = (req) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ message: "No token provided" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || "defaultsecret",
    );

    //pasamos al userId todo el token
    req.userId = decoded;
    console.log("Decoded token in upload middleware:", decoded);
    return "Authorized";
  } catch (err) {
    return "Unauthorized";
  }
};

module.exports = { upload, UploadMiddleware };
