const ProductService = require("../services/ProductService");
const { UploadMiddleware } = require("../middlewares/UploadMiddleware");
//update products function

async function UploadProducts(req, res) {
  // verificamos token

  const user = await UploadMiddleware(req);
  if (user == "Unauthorized") return "token no autorizado";

  // llamamos al servivice y pasamos parametros

  const serviceInstance = new ProductService();

  const response = serviceInstance.UpdateProducts(req.userId.userId, req.body);

  if (response == "Unauthorized")
    res.status(401).json({ message: "unauthorized user" });

  res.status(200).json({ message: "product posted !" });
}

//---------------------------------------------------------------------

module.exports = { UploadProducts };
